(function($) {
    checkboxToggleSearchListPages();
})(jQuery);
